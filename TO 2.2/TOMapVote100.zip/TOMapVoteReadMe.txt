Title         : TO MapVote 
Game          : Unreal Tournament & Tactical Ops v2
Version       : 1.00
Release Date  : 7/22/2001
Filenames     : TOMapVote100.u, TOMapVote100.int
Author        : Bruce Bickar aka BDB
Email Address : BDB@planetunreal.com or BBickar@carolina.rr.com
Web Page      : http://www.planetunreal.com/BDBUnreal

Description   : This mutator allows players to control what maps are played on a Tactical Ops server through voting.

Features      o Graphical user interface. At the end of each game a Voting Window will pop up automatically,
                so no key binding is required and there are no console commands to remember.

              o Screen-Shot preview. When a map is selected a screen-shot (picture) of the map will be displayed 
                along with information about the map such as the author and the recommended number of players. 
                If the player doesn't have the selected map file on their computer then it will indicate that 
                downloading is required.

              o Mid game map change option. The players can vote for a map at any time during the course of the game.
                If the required percentage of players place votes a Mid-Game vote will be initiated and all of the 
                players voting windows will be opened. They will have a limited time to vote.
                
              o Players can configure a keyboard key that can be used at any time during the game to open the voting window.
                This is not required because the voting window can/will automatically open it self at the end of each game. But
                if the players want to take advantage of the player kick voting or the early map voting features then this would
                be required. Also, the key configuration does not require any console commands or opening of the preferences menu.
                This key configuration is built in to the voting window which makes it much easier to do.
                It also will work with-out a Mod Menu INT file, this is important because INT files are not automatically 
                downloaded from the server in network play and Mod Menu configuration windows require an INT file.
                
              o A KeyBinder window will automatically pop-up when a player joins to the server. This KeyBinder will 
                allow the player to select a keyboard key by pressing the key and then clicking the "Set/Save" button.
                If a player joins a server and already has a key bound the window will not pop up. 

              o Tie breaker feature. Each player can only vote for one map. If all of the players vote the votes will be counted 
                and the map with the highest vote count will win. If there is a tie, then a map will be choosen at random from 
                the maps that tied for first place. 

              o Player Kick feature. Players can place "kick" votes against other players. If the percentage of players that
                vote against a particular player reaches the configurable kick requirement percentage then that player will 
                be disconnected from the server. If the kicked player reconnects to the server during the same game that he
                was kicked from, he/she will be re-kicked automatically. To clairify, This kick/ban only lasts until the end 
                of the current game, or until the map is changed. Note: The server administrator can not be kicked.
                Also, kick votes are tracked by PlayerID and not name so changing names will not affect it.
                New: If you are logged in as Admin then your kick vote will kick the player immediatly, no one else has to 
                vote. This makes it easier to kick players with weird names that can't be typed.

              o Remote dedicated server configuration window, which can be used by remote administrators to configure Map-Vote.
                There are no console configuration commands to look up and remember.

              o Works with all Tactical Ops games types. The server administrator can configure which types of maps will be
                loaded in to the map voting list. The following Map types can be turned on or off:
                - Auto Detect - Automatically detects the game type that the server was started with.
                - Tactical Ops - s_SWATGame (TO)
                - TO Death Match (DM)
                - TO Team Death Match (DM)
                - TO Last Man Standing (DM)
                - TO Assault (AS)
                - TO Capture The Flag (CTF)
                - TO Domination (DOM)
                       
              o Voting status. The main window displays a list of maps that were voted for and the amount of votes for
                each. It also shows player names that were had kick votes cast against them.
                You can now click the name of a map or player and it will select that map in the map list.
                      
              o Configurable End-Game voting time limit. At the end of a game the players have a set about of time to place their
                votes. If all players have not voted with in this time limit then a map change will be forced.

              o MapVoteHistory - MapVote now keeps track of all winning maps and supplies a report that shows how many 
                times each map has been played. Note: running the report take a bit of time. It was made to be slow
                on pupose to avoid adding lag to the server.
                New: To prevent server lag the report results will be truncated to the top 100 maps, also a limit of
                     one report at a time has been implemented.
         
              o Welcome Window - MapVote now has an optional welcome window the will open up when a player joins the server.
                This welcome window can be used to communicate server specific information , schedules, rules, etc.
                Note: it requires an HTTP web server. (more details below)
            
              o New Modes: MapVote now has 4 voting modes: 
                1. Majority - Each player gets to place 1 vote and the map with the most votes wins.
                2. Elimination - Maps are removed from the list until there are only X number of maps left. (X is configurable)
                3. Accumulation - If the map that a player has voted for does not win that vote is carried to the next game.
                4. Score - Player scores are used as the ammount of votes placed. So basically, the top players get choose the map.

              o Configurable No Repeat limit - You can now configure MapVote to remove the last X number of maps that
                have been played. X being some number.

              o New (just for Tactical Ops), A Weapons Purchasing Key Binder window has been added.
                This can be used to view key bindings and to add new weapon buying key binds. 
                It lists all of the weapons and inventory that can be purchased in TO 2.0.

Requirements  : Required version 436 or better of Unreal Tournament. (This include the players as well as the server)
                and Tactical Ops version 2.0 (http://www.tactical-ops.net/).
                
Installation Instruction :
              1. Place TOMapVote100.int in the \UnrealTournament\System directory.
              2. Place TOMapVote100.u in the \UnrealTournament\System directory.
              3. If you are using the Redirected/compressed download feature, place the TOMapVote100.u.uz in 
                 the download directory of you web server.

              4. ***Note: this if very important, it will not work without this.
                 Add "ServerPackages=TOMapVote100" to the \UnrealTournament\system\TacticalOps.ini file under 
                 the "[Engine.GameEngine]" section. 
               
Configuration : 1. Start the server with the "TO MapVote 1.0" mutator. (See decicated server setup instructions below)
                2. Connect to your server with UT/TO. 
                3. Login as Admin with the "ADMINLOGIN password" console command. 
                   Note: If you don't see a message like "YourPlayerName has become the administrator" then the password was wrong.
                   Note: If you have never set a password on your server then edit the TacticalOps.ini file and 
                   change the "AdminPassword" option to a password that you want.
                4. Press your MapVote HotKey. You should have seen the KeyBinder window when you first joined the server.
                   If not then enter "MUTATE BDBMAPVOTE VOTEMENU" in the console.
                5. Click the "Admin" tab which should be all the way to the right. 
                   If there is No "Admin" tab then you have not successfully logged in as administrator, close the window and go back to step 3.
                6. Change the options in the scrolling Admin window. There is a second half of the page which does not show.
                   Just use the scroll bar on the far right to scroll down.
                8. Click the "Save" button. This will save your selected options on the remote server 
                   If you made a change which will affect which types of maps are loaded then click the
                   "Reload Maps" button.
                9. Now close and reopen the voting window to refresh the map list.


Advanced Server Setup: For decicated server owners.
                       Put the appropriate command and parameters (found below) in your server batch file.

                Tactical Ops: 
                -----------------------------
                UCC server TO-Blister.unr?Game=s_SWAT.s_SWATGame?mutator=TOMapVote100.TOMapVote -INI=TacticalOps.ini -USERINI=TOUser.ini 

                TO Unreal-Tournament Game Types:
                -----------------------------
                UCC server DM-Morpheus.unr?Game=TOUT.s_DeathMatchPlus?mutator=TOMapVote100.TOMapVote 
                UCC server DM-Morpheus.unr?Game=TOUT.s_TeamDM?mutator=TOMapVote100.TOMapVote 
                UCC server DM-Morpheus.unr?Game=TOUT.s_UTLastManStanding?mutator=TOMapVote100.TOMapVote
                UCC server AS-Guardia.unr.unr?Game=TOUT.s_Assault?mutator=TOMapVote100.TOMapVote 
                UCC server CTF-LavaGiant.unr?Game=TOUT.s_CTF?mutator=TOMapVote100.TOMapVote
                UCC server DOM-Cinder.unr?Game=TOUT.s_Domination?mutator=TOMapVote100.TOMapVote 

Ini File Settings:
    [TOMapVote100.TOMapVote]
    bAutoDetect=True          <= used this to automatically set the gametype to what ever gametype the server was started with
    bTO=False                 <= Load Tactical Ops maps only
    bDM=False                 <= Load DeathMatch maps only  (for use with the TO DM game type)
    bLMS=False                <= Load Last Man Standing Maps  
    bTDM=False                <= Load Team Death Match Maps 
    bDOM=False                <= Load Domination maps
    bCTF=False                <= Load CTF maps
    bAS=False                 <= Load Assault Maps
    MsgTimeOut=30             <= This changes the amount of time that messages stay on the HUD, This is Client Side only and is not dictated by the server.
    VoteTimeLimit=50          <= Number of seconds to allow for voting at the end of the game. After this time is expired a map switch is forced.
    KickPercent=51            <= The percentage of Player votes that are required to kick someone
    bUseMapList=False         <= If True it will use the default MapList for the gametype to load the map names from, if false it will load all maps for the game type
    ScoreBoardDelay=6         <= number of seconds to show the Score board at the end of the game before opening the mapvote windows
    bAutoOpen=True            <= if True it will automatically open the MapVote windows at the end of the game. If false the server will just travel to the next map in the cycle
    bKickVote=True            <= If true players can place votes against other players to kick them
    RepeatLimit=4             <= This will cause MapVote to remove the last 4 maps that were played from the list of maps that you can vote for.
    bLoadScreenShot=True      <= If true it shows the screen shot of the map when it is selected, if false it does not. This is a Client side only setting.
    MapVoteHistoryType=TOMapVote100.MapVoteHistory1   <= This points to the MapVoteHistory code. Read the MapVote History section. 
    MidGameVotePercent=75     <= This is the percentage of players that must place votes to initiate a Mid Game vote. 
    Mode=Majority             <= This is the voting mode that effects how many votes each player gets. See documentation or Admin window for possible values.
    MinMapCount=1             <= This is for Elimination Mode only. In Elimation mode maps are removed from the list after being played. When the map list
                                 count reaches this limit, it will reload the list with all available maps. 
    ServerInfoURL=www.planetunreal.com/bdbunreal/serverinfo.htm  <= this is the Web site URL to use in the Welcome window (see doc)
    MapInfoURL=                        <= This is the web site url to look for Map Information (see doc)
    MapPreFixOverRide=        <= This can be used to play TO DeathMatch on TO-* type maps. It forces MapVote to load only maps that
                                 start with the specified PreFix. It only works when bAutoDetect is enabled.
    AccName[0]=               <= Dont mess with these Acc settings. They are used to store player names and vote counts when Accumulation Mode is enabled.
    AccName[1]=
    ~~~~~~~~~~~~
    AccVotes[0]=0
    AccVotes[1]=0
    ~~~~~~~~~~~~
    bEntryWindows=True      <= If you set this to false it will not open the Welcome Window or the KeyBinder window when a player joins the server.
                  
MapVoteHistory : MapVote keeps a record of maps played , the number of times each was played and the sequence
                 each was played. This information is stored separt from the default UT ini file because of the 
                 potental large size (up to 1020 maps). By default this information is stored in the MapVoteHistory1.ini
                 file. I do not recommend editing this file manually, but if you do here is the layout:
                 Example: MapVoteHistory1.ini
                 -------------------------------------------------------------------------------------------
                 [TOMapVote100.MapVoteHistory1]
                 M[0]=                             <== Note: this is left blank on purpose
                 M[1]=AS-Coldsteel                 <== M = MapName, MapNames are maintained in alphabetic order
                 M[2]=CTF-2symple                  <== If y
                 M[3]=CTF-4Faces
                 M[4]=CTF-AAhuNui
                 ...etc.
                 M[1022]=
                 M[1023]=
                 P[0]=0
                 P[1]=1
                 P[2]=7
                 P[3]=11
                 P[4]=9
                 ...etc.
                 P[1022]=0
                 P[1023]=0
                 S[0]=0
                 S[1]=41
                 S[2]=197
                 S[3]=166
                 S[4]=10
                 S[1022]=0
                 S[1023]=0
                 LastMapIndex=251                 <== This is the index nuber of the last map
                 -------------------------------------------------------------------------------------------

Welcome Window:
          The Welcome Window is a new feature that allows server owners to post
          information for the players to see when they join the server.
          When configured the Welcome Window will open as soon as the player 
          joins the server. The player can then read the inforamation or just close
          the window by clicking the "Close" button. 

          Requirements: 1. HTTP Web server (Micro$oft IIS, HTTP server, etc.)
                        2. An HTML file.
      
          Welcome Window Setup:
          ---------------------
          First you need to make the Welcome Window HTML source file.

          *** The in-game web browser is very very limited.
          You can not use images,tables tags,java-script, style-sheets, etc.

          So, What can you use ?
          Here are the comments directly from the "UWindowHTMLTextArea" class 
          that is used to render the HTML:
          -------------------------------------------------------------------
          HTML Currently Supported
          ========================
          Parsed on add
          -------------
          <body bgcolor=#ffffff link=#ffffff alink=#ffffff>...</body>
          <font color=#ffffff bgcolor=#ffffff>...</font>
          <br>
          <center>....</center>
          <p>
          <h1>...</h1>

          Parsed on add and display
          -------------------------
          <nobr>...</nobr>
          <a href="...">...</a>
          <b>...</b>
          <u>...</u>
          <blink>...</blink>

          Parsed only on display
          ----------------------
          & gt;
          & lt;
          & amp;
          & nbsp;

          Planned improvements
          --------------------
          <ul><li>item 1<li>item 2...</ul>
          <table>...</table>

          Bugs
          ----
          The parsing is pretty slack!
          ------------------------------------------------------------------ 

          So create an HTML and place it on your HTTP web server.
          Then goto the Admin configuration window in MapVote and scroll down to 
          the Advanced section.
          In the "Welcome Page Web Server URL" text box enter the web server address,
          port, path, and filename.
          Syntax:
          webservername.domainname:port/path/filename.htm

          Note: The port is not required, the default is 80. 
                Do Not include "http://" 

          Example: www.planetunreal.com:80/BDBUnreal/serverinfo.htm

          Note: Leaving the URL blank disables the Welcome Window.

Tactical Ops Weapon Purchasing KeyBinder User Insturctions:
--------------------------------------------------------------
     The Weapons KeyBinder is a little utility that was added to TOMapVote to help users bind
     keys to weapons and inventory purchasing commands. 
     Please read the Bind_AmmoWeaponsItems.txt file that came with Tactical Ops (\UnrealTournament\TactialOps directory)
     for more information on the commands.
     Note: the instructions in Bind_AmmoWeaponsItems.txt instructs the user to make Aliases. The KeyBinder doesn't
     use Aliases, instead it binds the commands to the key directly. Aliases were not used because it is not
     possible (not that I know of) to set/change aliases in-game and the number of unused aliases are very 
     limited. Not enough for all the weapons.
     
     Instructions:
     1. Open the MapVote window.
     2. Click the "KeyBinder" tab
     3. Press a key on your keyboard (for example: press the B key)
     4. The list box at the top section should change and show the "B" high lighted and beside it 
        it should show what command is associated with it (if any).
     5. Now click the check boxes (in the middle section of the keybinder) of the items that you want
        to buy. For example: click MP5 and Current Ammo.
     6. You should see commands added to the command text at the bottom. "s_kAmmoAuto 104|s_kAmmoAuto 999|"
     Note: You will probably want to buy more than one ammo clip. You will have to manually edit the command text 
           for this. Sorry.
           Just click the Commad Text Box at the bottom , move the cursor to the end and type "s_kAmmoAuto 999|"
           and repeat for how ever many times you want.
     7. Click the "SAVE" button to save your key bind.
     Now at the beginning of a game you can press the "B" key to buy an MP5 quickly.

  
Version History : 
         1.0 a. Conversion from BDBMapVote version 3.01 to TOMapVote100
             b. Fixed the detection of and switching to the TacticalOps team joining window when closing the
                welcome window or the keybinder windows. This also fixes the problem with the
                menu bar staying up.
             c. Added the Weapons keybinder window.
             d. Added the Admin Map Voting and Player Kicking feature. If logged in as admin then your votes count
                as 100%.
             e. Removed the "Open this window on Connect" check box on the welcome window. 
                The Welcome window will only open the first time a player connects to the server and not
                after map changes.

Thanks:      Special thanks to DrSin and Mongo for making and letting me use the WRI (Windows Replication Info) class.

Copyright / Permissions
-----------------------
Copyright Bruce D. Bickar 2000 - 2001
Authors may NOT use this code with out my permission.
You are NOT allowed to commercially exploit this release, i.e. put it on a CD
or any other electronic medium that is sold for money without my explicit
permission!
You MAY distribute this release through any electronic network (internet,
FIDO, local BBS etc.), provided you include this file and leave the archive
intact.
----------------------
UNREAL TOURNAMENT (c)1999 Epic Megagames, Inc.  All Rights Reserved.  
Distributed by GT Software, Inc. under license.  UNREAL TOURNAMENT and 
the UNREAL TOURNAMENT logo are registered trademarks of Epic Megagames, Inc. 
All other trademarks and trade names are properties of their respective owners.
